Python library for working with Open vSwitch
